import unittest
from hello import User
from hello import db

class ceshi(unittest.TestCase):
    
    def setUp(self):
        db.create_all()

    def tearDown(self):
        db.drop_all()
        
    def test_creatUser(self):
        self.user=User('huangzhixin')
        self.assertEqual(self.user.username,'huangzhixin')
    
    def test_userAge(self):
        self.user=User('huangzhixin')
        self.assertEqual(self.user.age,20)
	
    def test_userAgeInput(self):
        self.user=User('huangzhixin',25)
        self.assertEqual(self.user.age,25)
		
if __name__ == '__main__':
    unittest.main()
