import unittest
from hello import User
from hello import db

class ceshi(unittest.TestCase):
    
    def setUp(self):
        db.create_all()

    def tearDown(self):
        db.drop_all()
        
    def test_creatUser(self):
        self.user=User('zhoujuhui')
        self.assertEqual(self.user.username,'zhoujuhui')
    
    def test_userAge(self):
        self.user=User('zhoujuhui')
        self.assertEqual(self.user.age,20)
	
    def test_userAgeInput(self):
        self.user=User('zhoujuhui',24)
        self.assertEqual(self.user.age,24)
		
if __name__ == '__main__':
    unittest.main()
